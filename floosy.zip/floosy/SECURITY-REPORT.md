# FLOOSY security review

Scope: `index.html` (the only app file) and README. No backend, no authentication, no dependencies. Tested with scripted jsdom checks, not a real browser or penetration test.

## Issues found and fixed
| # | Issue | Severity | Where | Fix |
|---|-------|----------|-------|-----|
| 1 | Record/category IDs from a backup were accepted as any string and written unescaped into HTML attributes (`data-id`, `<option value>`). A crafted backup could inject an event handler (confirmed on the original file) and run script in the site's origin. | Medium (needs the user to import a hostile file) | `clean()`, `txRow`, goal/category templates | IDs must match `[A-Za-z0-9_-]`, reserved names rejected, and IDs are now escaped on output. A hostile stored state is quarantined and never rendered. |
| 2 | No Content Security Policy | Low | `<head>` | Meta CSP limiting scripts, styles, fonts, images, connections, `base-uri`, `form-action`, `object-src`. |
| 3 | Import dialog gave no way to export current data first | Low | import flow | Added "export current data first" button; previous state still kept in `floosy.prev`. |
| 4 | Double submit of dialogs possible | Low | dialog submit | Handler is cleared while it runs. |

Already good: text is escaped with `esc()`, toasts use `textContent`, imports are strictly validated with a size limit, imports and saves roll back on failure.

## Remaining risks
- CSP must keep `'unsafe-inline'` because the app is one file with inline script and style; a strict CSP would need splitting into separate files.
- localStorage is readable by anyone with access to the browser profile, and by any script on the same origin (`oa471279-star.github.io` is shared by all your Pages repos). Not encrypted.
- Data loss on clearing browser data or switching device unless a backup exists.
- Google Fonts is a third-party request (visitor IP goes to Google). Self-hosting Cairo/Inter would remove it.
- GitHub Pages cannot set HTTP security headers (`frame-ancestors`, HSTS control, etc.).

## Needs a backend or hosting change
- A private admin analytics page: use a small backend with real authentication (e.g. Cloudflare Workers or Firebase Auth) that calls the GA4 Data API with a service account kept on the server. Until then, use the Google Analytics dashboard.
- Cross-device sync and server-side access control.
- Real HTTP security headers (move to Cloudflare or Netlify in front of the site).
